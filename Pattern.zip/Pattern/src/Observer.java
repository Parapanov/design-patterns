public interface Observer {

    public  void update(Stock stocks);

}
