public class Apple extends  Stock {
    public Apple(){
        this.setName("Apple");
    }
}
