public class Microsoft extends  Stock{
    public Microsoft(){
        this.setName("Microsoft");
    }
}
