public class IBM extends  Stock {
    public IBM(){
        this.setName("IBM");
    }
}
